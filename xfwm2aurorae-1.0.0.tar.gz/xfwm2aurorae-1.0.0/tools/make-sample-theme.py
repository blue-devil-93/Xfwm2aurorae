#!/usr/bin/env python3
"""Writes a small demonstration xfwm4 theme so the converter can be tried
without an Xfce installation.

    python3 tools/make-sample-theme.py build/sample-xfwm4
    ./build/xfwm2aurorae build/sample-xfwm4 -o build/AuroraeSample
"""

import os
import sys

ACTIVE_TOP = "#2A76D2"
ACTIVE_MID = "#3584E4"
ACTIVE_EDGE = "#1C71D8"
INACTIVE_TOP = "#DADADA"
INACTIVE_MID = "#E8E8E8"
INACTIVE_EDGE = "#C4C4C4"
GLYPH_DARK = "#1A1A1A"
GLYPH_LIGHT = "#FFFFFF"
HOVER = "#FF7800"
HOVER_EDGE = "#C06000"

TITLE_ACTIVE = {"X": "c None", "a": f"c {ACTIVE_TOP}", "b": f"c {ACTIVE_MID}", "c": f"c {ACTIVE_EDGE}"}
TITLE_INACTIVE = {"X": "c None", "a": f"c {INACTIVE_TOP}", "b": f"c {INACTIVE_MID}", "c": f"c {INACTIVE_EDGE}"}


def write_xpm(path, rows, palette):
    """palette maps a single pixel character to an XPM colour description."""
    height = len(rows)
    width = len(rows[0])
    for row in rows:
        if len(row) != width:
            raise SystemExit(f"row width mismatch in {path}: {len(row)} != {width}")
    for row in rows:
        for cell in set(row):
            if cell not in palette:
                raise SystemExit(f"pixel '{cell}' has no colour in {path}")

    keys = sorted(palette)
    if len(keys) != len(set(keys)) or any(len(key) != 1 for key in keys):
        raise SystemExit(f"palette keys must be single characters in {path}")

    lines = ["/* XPM */", "static char * pixmap_xpm[] = {", f'"{width} {height} {len(keys)} 1",']
    for key in keys:
        lines.append(f'"{key}   {palette[key]}",')
    lines.extend(f'"{row}",' for row in rows[:-1])
    lines.append(f'"{rows[-1]}"}};')

    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="ascii") as handle:
        handle.write("\n".join(lines) + "\n")


def title_rows(width, height, top, mid, edge):
    """A title bar strip using the same 'a'/'b'/'c' keys as TITLE_ACTIVE."""
    rows = []
    for y in range(height):
        if y == 0:
            rows.append(top * width)
        elif y >= height - 2:
            rows.append(edge * width)
        else:
            rows.append(mid * width)
    return rows


def corner_rows(width, height, fill, side, cut_start, cut_depth):
    """Rounded corner; 'X' is transparent, 'f' is the fill key."""
    rows = []
    for y in range(height):
        row = [fill] * width
        if cut_start <= y < cut_start + cut_depth:
            cut = cut_depth - (y - cut_start)
            for x in range(width):
                if (side == "left" and x < cut) or (side == "right" and x >= width - cut):
                    row[x] = "X"
        rows.append("".join(row))
    return rows


def button_rows(size, glyph, glyph_key, fill_key, rim_key):
    """A round button with a simple bitmap glyph."""
    rows = []
    for y in range(size):
        row = []
        for x in range(size):
            dx = x - (size - 1) / 2
            dy = y - (size - 1) / 2
            distance = (dx * dx + dy * dy) ** 0.5
            if distance > size / 2 - 0.5:
                row.append("X")
            elif distance > size / 2 - 2.0:
                row.append(rim_key)
            else:
                row.append(fill_key)
        rows.append(row)

    top = (size - len(glyph)) // 2
    for index, line in enumerate(glyph):
        for index2, cell in enumerate(line):
            if cell == "#":
                rows[top + index][(size - len(line)) // 2 + index2] = glyph_key
    return ["".join(row) for row in rows]


def main():
    target = sys.argv[1] if len(sys.argv) > 1 else "sample-xfwm4"
    size = 22

    close_glyph = ["#####", "#####", "#####", "#####", "#####"]
    minimise_glyph = ["#############"]
    maximise_glyph = ["#############", "#...........#", "#...........#", "#...........#", "#############"]

    def path(name):
        return os.path.join(target, name)

    # Title bar: title-1 is the left cap, title-5 the right cap and
    # title-2/3/4 the stretchable middle fill that becomes decoration-top.
    write_xpm(path("title-1-active.xpm"), title_rows(8, 29, "a", "b", "c"), TITLE_ACTIVE)
    for name in ("title-2-active", "title-3-active", "title-4-active"):
        write_xpm(path(f"{name}.xpm"), ["b" * 4] * 29, {"b": f"c {ACTIVE_MID} s active_mid_2"})
    write_xpm(path("title-5-active.xpm"), title_rows(8, 29, "a", "b", "c"), TITLE_ACTIVE)

    write_xpm(path("title-1-inactive.xpm"), title_rows(8, 29, "a", "b", "c"), TITLE_INACTIVE)
    for name in ("title-2-inactive", "title-3-inactive", "title-4-inactive"):
        write_xpm(path(f"{name}.xpm"), ["b" * 4] * 29, {"b": "c inactive_mid_2"})
    write_xpm(path("title-5-inactive.xpm"), title_rows(8, 29, "a", "b", "c"), TITLE_INACTIVE)

    # Frame border strip above the title bar (frame_border_top in themerc).
    write_xpm(path("top-active.xpm"), ["a"], {"a": f"c {ACTIVE_TOP}"})
    write_xpm(path("top-inactive.xpm"), ["a"], {"a": f"c {INACTIVE_TOP}"})

    # Corners, including the transparent rounding.
    write_xpm(path("top-left-active.xpm"), corner_rows(10, 29, "b", "left", 0, 6), TITLE_ACTIVE)
    write_xpm(path("top-right-active.xpm"), corner_rows(10, 29, "b", "right", 0, 6), TITLE_ACTIVE)
    write_xpm(path("top-left-inactive.xpm"), corner_rows(10, 29, "b", "left", 0, 6), TITLE_INACTIVE)
    write_xpm(path("top-right-inactive.xpm"), corner_rows(10, 29, "b", "right", 0, 6), TITLE_INACTIVE)

    # Sides and bottom: thin strips that xfwm4 tiles along the edge.
    for state, colour in (("active", ACTIVE_EDGE), ("inactive", INACTIVE_EDGE)):
        write_xpm(path(f"left-{state}.xpm"), ["a" * 3], {"a": f"c {colour}"})
        write_xpm(path(f"right-{state}.xpm"), ["a" * 3], {"a": f"c {colour}"})
        write_xpm(path(f"bottom-{state}.xpm"), ["a"] * 3, {"a": f"c {colour}"})

    for state, fill, edge in (
        ("active", ACTIVE_MID, ACTIVE_EDGE),
        ("inactive", INACTIVE_MID, INACTIVE_EDGE),
    ):
        palette = {"X": "c None", "f": f"c {fill}", "e": f"c {edge}"}
        write_xpm(path(f"bottom-left-{state}.xpm"), corner_rows(10, 8, "f", "left", 4, 4), palette)
        write_xpm(path(f"bottom-right-{state}.xpm"), corner_rows(10, 8, "f", "right", 4, 4), palette)

    # 'a' is the glyph, 'b' the rim and 'c' the fill; 'X' stays transparent.
    variants = {
        "active": (GLYPH_LIGHT, ACTIVE_EDGE, ACTIVE_MID),
        "inactive": (GLYPH_DARK, INACTIVE_EDGE, INACTIVE_MID),
        "prelight": (GLYPH_LIGHT, HOVER_EDGE, HOVER),
        "pressed": (GLYPH_LIGHT, "#8A4300", HOVER_EDGE),
    }
    glyphs = {"close": close_glyph, "hide": minimise_glyph, "maximize": maximise_glyph}

    for name, glyph in glyphs.items():
        for variant, (glyph_colour, rim, fill) in variants.items():
            write_xpm(
                path(f"{name}-{variant}.xpm"),
                button_rows(size, glyph, "a", "c", "b"),
                {"X": "c None", "a": f"c {glyph_colour}", "b": f"c {rim}", "c": f"c {fill}"},
            )

    themerc = """# Demonstration theme written by tools/make-sample-theme.py
active_text_color=#FFFFFF
inactive_text_color=inactive_text_color_2
active_text_shadow_color=#00000088
inactive_text_shadow_color=#FFFFFF88
button_offset=1
button_spacing=3
full_width_title=true
frame_border_top=5
title_alignment=left
title_shadow_active=false
title_shadow_inactive=under
title_horizontal_offset=2
button_layout=O|HMC
"""
    with open(path("themerc"), "w", encoding="utf-8") as handle:
        handle.write(themerc)

    print(f"wrote sample xfwm4 theme to {target}")


if __name__ == "__main__":
    main()
