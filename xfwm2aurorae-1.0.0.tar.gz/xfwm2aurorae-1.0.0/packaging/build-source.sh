#!/bin/sh
# Build the release source tarball for xfwm2aurorae.
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

NAME=xfwm2aurorae
VERSION=${VERSION:-1.0.0}
PKG="$NAME-$VERSION"
DIST=dist
STAGE=build/srctar/$PKG

echo ">> collecting $PKG source"
rm -rf build/srctar
install -d "$STAGE" "$DIST"
for f in CMakeLists.txt README.md LICENSE; do
	install -m 0644 "$f" "$STAGE/"
done
cp -R src tools packaging "$STAGE"/
find "$STAGE" \( -name '__pycache__' -o -name '*.pyc' -o -name '*.o' \) \
	-exec rm -rf {} + 2>/dev/null || true

out="$DIST/$PKG.tar.gz"
rm -f "$out"
tar --sort=name --owner=0 --group=0 --numeric-owner \
	--mtime="$(date -u -d "@${SOURCE_DATE_EPOCH:-$(date +%s)}" '+%Y-%m-%d %H:%M:%SZ')" \
	-C build/srctar -cf - "$PKG" | gzip -9n > "$out"
echo ">> built $out ($(du -h "$out" | cut -f1))"
