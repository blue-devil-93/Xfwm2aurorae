#!/bin/sh
# Build an amd64 Debian package for xfwm2aurorae.
# Needs only dpkg-deb and a C++ compiler (no debhelper, no fakeroot).
#   ./packaging/build-deb.sh
#   VERSION=1.1.0 ./packaging/build-deb.sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

NAME=xfwm2aurorae
VERSION=${VERSION:-1.0.0}
REVISION=${REVISION:-1}
ARCH=${ARCH:-amd64}
MAINTAINER=${MAINTAINER:-"Local Package Build <root@localhost>"}
CXX=${CXX:-g++}
BIN=build/$NAME
STAGE=build/pkgroot/$NAME
DIST=dist

echo ">> compiling $NAME $VERSION"
mkdir -p build "$DIST"
$CXX -std=c++17 -O2 -Wall -Wextra -Isrc src/*.cpp -o "$BIN"

echo ">> staging"
rm -rf build/pkgroot
install -d -m 0755 "$STAGE/DEBIAN" "$STAGE/usr/bin" "$STAGE/usr/share/doc/$NAME"
install -m 0755 "$BIN" "$STAGE/usr/bin/$NAME"
strip --strip-unneeded "$STAGE/usr/bin/$NAME"
install -m 0644 README.md "$STAGE/usr/share/doc/$NAME/README.md"

# Dependency versions come from the symbol versions the binary really needs.
glibc=$(objdump -T "$BIN" | grep -o 'GLIBC_[0-9.]*' | sed 's/^GLIBC_//' | sort -V | tail -1)
glibcxx=$(objdump -T "$BIN" | grep -o 'GLIBCXX_[0-9.]*' | sed 's/^GLIBCXX_//' | sort -V | tail -1)
libstdcpp=""
case "$glibcxx" in
  3.4.33) libstdcpp=14.1 ;;
  3.4.32) libstdcpp=13.1 ;;
  3.4.31) libstdcpp=13.2 ;;
  3.4.30) libstdcpp=12.1 ;;
  3.4.29) libstdcpp=11.2 ;;
  3.4.28) libstdcpp=10.1 ;;
  3.4.2[67]) libstdcpp=9.1 ;;
esac
depends="libc6 (>= ${glibc:-2.34})"
if [ -n "$libstdcpp" ]; then
	depends="$depends, libstdc++6 (>= $libstdcpp)"
else
	depends="$depends, libstdc++6"
fi
installed_size=$(du -sk --exclude=DEBIAN "$STAGE" | cut -f1)

cat > "$STAGE/DEBIAN/control" <<EOF
Package: $NAME
Version: $VERSION-$REVISION
Architecture: $ARCH
Maintainer: $MAINTAINER
Installed-Size: $installed_size
Depends: $depends
Section: x11
Priority: optional
Description: convert xfwm4 window themes to KWin Aurorae themes
 Reads an Xfce xfwm4 theme folder (the .xpm pixmaps and the themerc
 settings file) and writes a KWin Aurorae theme: one decoration.svg with
 every pixmap embedded as a PNG, one SVG per title bar button, and an rc
 file carrying over the title colours, shadows and metrics.
 .
 No external libraries are needed, the XPM reader and the PNG encoder are
 part of the program. The result is installed per user into
 ~/.local/share/aurorae/themes/ and picked in System Settings.
EOF

cat > "$STAGE/usr/share/doc/$NAME/copyright" <<EOF
Format: https://www.debian.org/doc/packaging-manuals/copyright-format/1.0/
Upstream-Name: $NAME
Source: locally built

Files: *
Copyright: 2026 the $NAME authors
License: MIT
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 .
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 .
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
EOF
chmod 0644 "$STAGE/usr/share/doc/$NAME/copyright"

{
	printf '%s (%s-%s) unstable; urgency=medium\n\n' "$NAME" "$VERSION" "$REVISION"
	printf '  * Initial packaging of the xfwm4 to Aurorae theme converter.\n\n'
	printf ' -- %s  %s\n' "$MAINTAINER" "$(date -R)"
} | gzip -9n > "$STAGE/usr/share/doc/$NAME/changelog.Debian.gz"
chmod 0644 "$STAGE/usr/share/doc/$NAME/changelog.Debian.gz"

( cd "$STAGE" && find usr -type f -exec md5sum {} + | sort -k2 > DEBIAN/md5sums )

DEB="$DIST/${NAME}_${VERSION}-${REVISION}_${ARCH}.deb"
rm -f "$DEB"
dpkg-deb --build --root-owner-group -Zxz "$STAGE" "$DEB" >/dev/null
echo ">> built $DEB ($(du -h "$DEB" | cut -f1))"
