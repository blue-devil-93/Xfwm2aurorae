cmake_minimum_required(VERSION 3.16)
project(xfwm2aurorae LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

if(NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE Release)
endif()

add_executable(xfwm2aurorae
    src/main.cpp
    src/aurorae.cpp
    src/theme.cpp
    src/xpm.cpp
    src/png.cpp
)

target_include_directories(xfwm2aurorae PRIVATE src)

if(MSVC)
    target_compile_options(xfwm2aurorae PRIVATE /W4)
else()
    target_compile_options(xfwm2aurorae PRIVATE -Wall -Wextra)
endif()

# GCC 8 needs the filesystem library as a separate target.
if(CMAKE_CXX_COMPILER_ID STREQUAL "GNU" AND CMAKE_CXX_COMPILER_VERSION VERSION_LESS 9.0)
    target_link_libraries(xfwm2aurorae PRIVATE stdc++fs)
endif()

install(TARGETS xfwm2aurorae RUNTIME DESTINATION bin)
