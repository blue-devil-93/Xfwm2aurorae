# xfwm2aurorae

Converts an **xfwm4** window theme (Xfce, a folder full of `.xpm` pixmaps plus a
`themerc` settings file) into an **Aurorae** theme for KWin (KDE Plasma).

The whole set of XPM pixmaps is bundled into one `decoration.svg`, and the xfwm4
colour settings are carried over into the `<Theme>rc` config file, so both the
graphics and the colours move across in one step.

## Build

```sh
cmake -S . -B build
cmake --build build -j
```

or, without CMake:

```sh
g++ -std=c++17 -O2 -Isrc src/*.cpp -o xfwm2aurorae
```

No external libraries are needed: the XPM reader and the PNG encoder are part of
the program.

## Use

```sh
# a system or user theme: .../themes/<Name>/xfwm4
./xfwm2aurorae /usr/share/themes/Daloa/xfwm4 -o Daloa

# or just point at the theme folder, xfwm4/ is found automatically
./xfwm2aurorae ~/.themes/Kokodi -o Kokodi
```

Options:

| Option | Meaning |
| --- | --- |
| `-o, --out DIR` | theme folder to create (default `./<name>`) |
| `-n, --name NAME` | Aurorae theme name (default: taken from the source folder) |
| `-s, --symbol N=#RGB` | override an xfwm4 colour symbol, can be repeated |
| `-q, --quiet` | warnings and errors only |

Install the result by copying the output folder into
`~/.local/share/aurorae/themes/` (system wide: `/usr/share/aurorae/themes/`) and
pick it under *System Settings → Window Decorations*. The folder name, the
`<Name>rc` file and `X-KDE-PluginInfo-Name` must all match; the tool names them
after `--name` for you.

A demo theme can be generated to try things out:

```sh
python3 tools/make-sample-theme.py build/sample-xfwm4
./build/xfwm2aurorae build/sample-xfwm4 -o AuroraeSample
```

## What gets mapped

Each XPM is decoded to RGBA (including the transparency of `None`), re-encoded
as PNG and embedded as a base64 data URI inside the SVG, positioned as a nine
slice frame. Aurorae addresses elements by id and stretches them, so the SVG is
both the theme and a readable preview of it.

### Decoration (`decoration.svg`)

| Aurorae element | xfwm4 pixmap |
| --- | --- |
| `decoration-top` | `title-2-active`, stacked under `top-active` when that is a thin frame border |
| `decoration-topleft` / `decoration-topright` | `top-left-active`, `top-right-active` |
| `decoration-left` / `decoration-right` | `left-active`, `right-active` |
| `decoration-bottom` | `bottom-active` |
| `decoration-bottomleft` / `decoration-bottomright` | `bottom-left-active`, `bottom-right-active` |
| `decoration-center` | transparent, the window paints there |

Every element is written a second time with the `decoration-inactive-` prefix
when the theme ships `-inactive` pixmaps; otherwise Aurorae reuses the active
frame, which is what xfwm4 does too.

### Buttons

`close`, `maximize` (plus `restore`), `minimize` (from `hide`), `shade` and
`alldesktops` (from `stick`) each get their own SVG. Aurorae names button states
`<state>-center`, so `-active`, `-inactive`, `-prelight` (hover), `-pressed` and
`-toggled-pressed` are mapped onto `active-center`, `inactive-center`,
`hover-center`, `pressed-center`, and so on.

### Config (`<Name>rc`)

Values are derived from `themerc`:

| Aurorae key | Source |
| --- | --- |
| `ActiveTextColor`, `InactiveTextColor` | `active_text_color`, `inactive_text_color` |
| `UseTextShadow`, `Active/InactiveTextShadowColor`, offsets | `title_shadow_active` / `_inactive` (`false`, `under`, `outset`) and `active/inactive_text_shadow_color` |
| `TitleAlignment` | `title_alignment` |
| `LeftButtons`, `RightButtons` | `button_layout`, translating xfwm4 letters to KWin ones (`O`→`M`, `T`→`S`, `H`→`I`, `S`→`L`, `M`→`A`, `C`→`X`) and splitting at `|` |
| `TitleHeight`, `TitleEdgeTop` | height of the title strip and of the frame border above it |
| `BorderLeft`, `BorderRight`, `BorderBottom` | thickness of the side and bottom pixmaps |
| `ButtonWidth`, `ButtonHeight`, `ButtonSpacing`, `ButtonMarginTop` | button pixmap size and `button_spacing` |
| `TitleEdgeLeft/Right`, `TitleBorderLeft/Right` | `button_offset`, `title_horizontal_offset` |

`Shadow` is set to `false` because the generated frame has no shadow padding.

## Colour symbols

xfwm4 pixmaps often use named colours such as `active_mid_2`, which are looked
up in the GTK theme at runtime and therefore are not stored in the theme folder.
The tool ships a neutral default palette for the common names and reports every
symbol it had to guess, so they can be corrected:

```sh
./xfwm2aurorae ~/.themes/Foo/xfwm4 -o Foo -s active_mid_2=#336699 -s inactive_mid_2=#dddddd
```

The `s` (symbol) name embedded in an XPM is used when the literal colour cannot
be resolved, so themes that only ship symbols still convert.

## Limitations

* Only `.xpm` pixmaps are read; themes that ship only `.png` frames are skipped
  (most xfwm4 themes keep the XPMs next to the PNGs).
* xfwm4 tiles the edges, Aurorae stretches them. For the flat or gradient strips
  that themes use this looks identical; a hand drawn, non-repeating edge texture
  will be scaled instead of repeated.
* The frame is a single bitmap per side, so the decoration is not re-rendered at
  fractional scale factors — KWin scales the embedded images.
* No `decoration-maximized`, `decoration-opaque`, `innerborder` or `mask`
  elements are generated; Aurorae falls back to the normal frame, which means
  blur behind the title bar is off for the converted theme.
* The window menu button has no pixmap in Aurorae themes (it is drawn from an
  icon), so `menu`/`O` is only carried into the button layout.

## Debian package

```sh
./packaging/build-deb.sh                 # -> dist/xfwm2aurorae_1.0.0-1_amd64.deb
VERSION=1.1.0 REVISION=2 ./packaging/build-deb.sh
```

The script needs only `dpkg-deb` and a C++ compiler; there is no `debian/`
folder and no debhelper. It stages the release binary (stripped), `README.md`,
`copyright` and `changelog.Debian.gz` under `usr/`, writes `control` with the
dependency versions taken from the symbol versions the binary actually needs,
and builds with `dpkg-deb --root-owner-group -Zxz`.

Set `MAINTAINER="Your Name <you@example.com>"` to change the `Maintainer:`
field. The binary is compiled against this machine's C library, so the package
requires `libc6 (>= 2.38)` and `libstdc++6 (>= 13.1)` — Ubuntu 24.04 and newer,
Debian 13 and newer. To support an older distribution, build the package on that
distribution instead of cross-building it.

Install with:

```sh
sudo apt install ./xfwm2aurorae_1.0.0-1_amd64.deb
```

## Source tarball

```sh
./packaging/build-source.sh              # -> dist/xfwm2aurorae-1.0.0.tar.gz
VERSION=1.1.0 ./packaging/build-source.sh
```

The archive unpacks into `xfwm2aurorae-<version>/` and contains everything
needed to build: `CMakeLists.txt`, `src/`, `tools/` (the sample theme
generator), `packaging/`, `README.md` and `LICENSE`. No build output, no
binaries. It is created with sorted entries, `root/root` ownership and a fixed
timestamp, so the same source always produces the same bytes
(`SOURCE_DATE_EPOCH` overrides the timestamp).

To turn it into a `.dsc` source package for `dpkg-source`, copy it to
`xfwm2aurorae_1.0.0.orig.tar.gz` and add a `debian/` folder.
