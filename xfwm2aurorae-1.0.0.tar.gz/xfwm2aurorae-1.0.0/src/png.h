// Self contained PNG encoder (stored deflate blocks) plus base64, so the
// tool needs no external image libraries.
#pragma once

#include <string>

#include "image.h"

std::string encodePng(const Image &image);
std::string base64Encode(const std::string &data);
std::string pngDataUri(const Image &image);
