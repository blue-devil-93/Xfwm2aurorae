#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <string>
#include <vector>

#include "aurorae.h"

namespace fs = std::filesystem;

namespace {

void printUsage(const char *program)
{
    std::cout << "xfwm2aurorae - convert an xfwm4 window theme into an Aurorae (KWin) theme\n\n"
              << "Usage:\n"
              << "  " << program << " [options] <xfwm4 theme folder>\n\n"
              << "The folder is the one holding 'themerc' and the *.xpm files, for example\n"
              << "/usr/share/themes/Default/xfwm4. Passing the theme folder above it\n"
              << "(/usr/share/themes/Default) works as well.\n\n"
              << "Options:\n"
              << "  -o, --out DIR         theme folder to create (default: ./<name>)\n"
              << "  -n, --name NAME       Aurorae theme name (default: derived from the folder)\n"
              << "  -s, --symbol N=#RGB   override an xfwm4 colour symbol, repeatable\n"
              << "  -q, --quiet           print warnings and errors only\n"
              << "  -h, --help            show this help\n\n"
              << "Install the result by copying the output folder into\n"
              << "  ~/.local/share/aurorae/themes/\n"
              << "then choose it under System Settings > Window Decorations.\n";
}

std::string deriveName(const fs::path &source)
{
    if (source.filename() == "xfwm4" && source.has_parent_path()) {
        const std::string parent = source.parent_path().filename().string();
        if (!parent.empty()) {
            return parent;
        }
    }
    std::string name = source.filename().string();
    if (name.empty()) {
        name = "AuroraeTheme";
    }
    return name;
}

} // namespace

int main(int argc, char **argv)
{
    std::string source;
    std::string outDir;
    std::string name;
    std::vector<std::string> symbols;
    bool quiet = false;

    for (int i = 1; i < argc; ++i) {
        const std::string argument = argv[i];

        auto value = [&](const char *what) -> std::string {
            if (i + 1 >= argc) {
                std::cerr << "error: " << argument << " needs " << what << "\n";
                std::exit(2);
            }
            return argv[++i];
        };

        if (argument == "-h" || argument == "--help") {
            printUsage(argv[0]);
            return 0;
        } else if (argument == "-o" || argument == "--out") {
            outDir = value("a directory");
        } else if (argument == "-n" || argument == "--name") {
            name = value("a name");
        } else if (argument == "-s" || argument == "--symbol") {
            symbols.push_back(value("name=#rrggbb"));
        } else if (argument == "-q" || argument == "--quiet") {
            quiet = true;
        } else if (!argument.empty() && argument[0] == '-') {
            std::cerr << "error: unknown option " << argument << "\n";
            return 2;
        } else if (source.empty()) {
            source = argument;
        } else {
            std::cerr << "error: more than one theme folder given\n";
            return 2;
        }
    }

    if (source.empty()) {
        printUsage(argv[0]);
        return 2;
    }

    std::error_code ec;
    fs::path sourceDir = fs::absolute(source, ec);
    if (ec) {
        std::cerr << "error: cannot resolve " << source << "\n";
        return 1;
    }
    if (fs::is_directory(sourceDir / "xfwm4", ec)) {
        sourceDir /= "xfwm4";
    }

    if (name.empty()) {
        name = deriveName(sourceDir);
    }
    if (outDir.empty()) {
        outDir = name;
    }

    ConvertOptions options;
    options.sourceDir = sourceDir;
    options.outputDir = fs::absolute(outDir, ec);
    options.themeName = name;
    options.symbolOverrides = symbols;

    if (options.outputDir.filename() != name) {
        std::cerr << "note: the theme folder '" << options.outputDir.filename().string() << "' does not match the theme name '"
                  << name << "'; Aurorae matches both, so rename one of them if the theme does not show up\n";
    }

    const ConvertResult result = convertTheme(options);

    if (!result.ok) {
        std::cerr << "error: " << result.error << "\n";
        for (const std::string &warning : result.warnings) {
            std::cerr << "  warning: " << warning << "\n";
        }
        return 1;
    }

    if (!quiet) {
        std::cout << "xfwm4 theme : " << options.sourceDir.string() << "\n";
        std::cout << "Aurorae name: " << options.themeName << "\n";
        std::cout << "written to  : " << options.outputDir.string() << "\n\n";

        std::cout << "Files:\n";
        for (const std::string &file : result.written) {
            std::cout << "  " << file << "\n";
        }

        std::cout << "\nPixmap mapping:\n";
        for (const auto &entry : result.mapped) {
            std::cout << "  " << entry.first << "  <-  " << entry.second << "\n";
        }

        std::cout << "\nInstall with:\n  cp -r " << options.outputDir.string()
                  << " ~/.local/share/aurorae/themes/\n";
    }

    if (!result.warnings.empty()) {
        std::cout << "\nWarnings (" << result.warnings.size() << "):\n";
        for (const std::string &warning : result.warnings) {
            std::cout << "  - " << warning << "\n";
        }
    }

    return 0;
}
