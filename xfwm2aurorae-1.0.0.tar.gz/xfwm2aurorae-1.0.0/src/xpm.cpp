#include "xpm.h"

#include <cctype>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <map>
#include <sstream>

namespace {

std::string readFile(const std::string &path)
{
    std::ifstream in(path, std::ios::binary);
    if (!in) {
        return std::string();
    }
    std::ostringstream buffer;
    buffer << in.rdbuf();
    return buffer.str();
}

// Pulls out every C string literal in the file, which is all an XPM is made of.
std::vector<std::string> extractStrings(const std::string &text)
{
    std::vector<std::string> out;
    std::string current;
    bool inside = false;

    for (std::size_t i = 0; i < text.size(); ++i) {
        const char c = text[i];
        if (!inside) {
            if (c == '"') {
                inside = true;
                current.clear();
            }
            continue;
        }
        if (c == '\\' && i + 1 < text.size()) {
            const char escaped = text[++i];
            switch (escaped) {
            case 'n':
                current.push_back('\n');
                break;
            case 't':
                current.push_back('\t');
                break;
            case 'r':
                current.push_back('\r');
                break;
            default:
                current.push_back(escaped);
                break;
            }
            continue;
        }
        if (c == '"') {
            inside = false;
            out.push_back(current);
            continue;
        }
        current.push_back(c);
    }
    return out;
}

std::string fileName(const std::string &path)
{
    return std::filesystem::path(path).filename().string();
}

} // namespace

XpmLoadResult loadXpm(const std::string &path, const SymbolTable &symbols)
{
    XpmLoadResult result;
    const std::string text = readFile(path);
    if (text.empty()) {
        result.warnings.push_back("cannot read " + path);
        return result;
    }

    const std::vector<std::string> strings = extractStrings(text);
    if (strings.empty()) {
        result.warnings.push_back("no XPM data in " + fileName(path));
        return result;
    }

    int width = 0;
    int height = 0;
    int colorCount = 0;
    int charsPerPixel = 0;
    if (std::sscanf(strings[0].c_str(), "%d %d %d %d", &width, &height, &colorCount, &charsPerPixel) != 4) {
        result.warnings.push_back("unreadable XPM header in " + fileName(path));
        return result;
    }
    if (width <= 0 || height <= 0 || width > 8192 || height > 8192 || colorCount <= 0 || colorCount > 4096
        || charsPerPixel < 1 || charsPerPixel > 2) {
        result.warnings.push_back("unsupported XPM geometry in " + fileName(path));
        return result;
    }
    if (strings.size() < static_cast<std::size_t>(1 + colorCount + height)) {
        result.warnings.push_back("truncated XPM in " + fileName(path));
        return result;
    }

    std::map<std::string, Rgba> colors;
    for (int i = 0; i < colorCount; ++i) {
        const std::string &line = strings[static_cast<std::size_t>(1 + i)];
        if (static_cast<int>(line.size()) < charsPerPixel) {
            continue;
        }

        const std::string key = line.substr(0, static_cast<std::size_t>(charsPerPixel));
        const std::string rest = line.substr(static_cast<std::size_t>(charsPerPixel));

        std::string colorValue;
        std::string symbolName;
        std::size_t index = 0;
        while (index < rest.size()) {
            while (index < rest.size() && std::isspace(static_cast<unsigned char>(rest[index]))) {
                ++index;
            }
            if (index >= rest.size()) {
                break;
            }
            const char kind = rest[index++];
            while (index < rest.size() && std::isspace(static_cast<unsigned char>(rest[index]))) {
                ++index;
            }
            const std::size_t start = index;
            while (index < rest.size() && !std::isspace(static_cast<unsigned char>(rest[index]))) {
                ++index;
            }
            const std::string value = rest.substr(start, index - start);
            if (kind == 'c') {
                colorValue = value;
            } else if (kind == 's') {
                symbolName = value;
            }
        }

        Rgba color{0, 0, 0, 0};
        bool resolved = false;
        if (!colorValue.empty()) {
            resolved = resolveColor(colorValue, symbols, color);
        }
        if (!resolved && !symbolName.empty()) {
            resolved = resolveColor(symbolName, symbols, color);
        }
        if (!resolved) {
            result.warnings.push_back("unknown colour '" + colorValue + "' in " + fileName(path) + ", drawn transparent");
        }
        colors[key] = color;
    }

    result.image.resize(width, height);
    for (int y = 0; y < height; ++y) {
        const std::string &row = strings[static_cast<std::size_t>(1 + colorCount + y)];
        for (int x = 0; x < width; ++x) {
            const std::size_t offset = static_cast<std::size_t>(x) * static_cast<std::size_t>(charsPerPixel);
            std::string key(static_cast<std::size_t>(charsPerPixel), ' ');
            if (offset + static_cast<std::size_t>(charsPerPixel) <= row.size()) {
                key = row.substr(offset, static_cast<std::size_t>(charsPerPixel));
            }
            auto it = colors.find(key);
            result.image.at(x, y) = it == colors.end() ? Rgba{0, 0, 0, 0} : it->second;
        }
    }

    result.ok = true;
    return result;
}
