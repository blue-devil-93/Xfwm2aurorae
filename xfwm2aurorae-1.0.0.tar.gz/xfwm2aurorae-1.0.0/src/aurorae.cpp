#include "aurorae.h"

#include <algorithm>
#include <cmath>
#include <cctype>
#include <fstream>
#include <set>
#include <sstream>

#include "png.h"
#include "theme.h"
#include "xpm.h"

namespace fs = std::filesystem;

namespace {

std::string toLower(std::string text)
{
    for (char &c : text) {
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    }
    return text;
}

std::string trim(const std::string &text)
{
    std::size_t begin = 0;
    std::size_t end = text.size();
    while (begin < end && std::isspace(static_cast<unsigned char>(text[begin]))) {
        ++begin;
    }
    while (end > begin && std::isspace(static_cast<unsigned char>(text[end - 1]))) {
        --end;
    }
    return text.substr(begin, end - begin);
}

std::string xmlEscape(const std::string &text)
{
    std::string out;
    out.reserve(text.size());
    for (char c : text) {
        switch (c) {
        case '&':
            out += "&amp;";
            break;
        case '<':
            out += "&lt;";
            break;
        case '>':
            out += "&gt;";
            break;
        case '"':
            out += "&quot;";
            break;
        default:
            out.push_back(c);
            break;
        }
    }
    return out;
}

struct Builder {
    const ConvertOptions *opts = nullptr;
    SymbolTable symbols;
    std::vector<std::string> warnings;
    std::map<std::string, std::string> mapped;
};

// Loads the first pixmap that exists from a list of candidate base names.
// The name that was used is reported through "chosen" so the summary can show
// which file ended up in which SVG element.
Image pick(const Builder &builder, const std::vector<std::string> &candidates, std::string *chosen)
{
    if (chosen != nullptr) {
        chosen->clear();
    }

    for (const std::string &candidate : candidates) {
        const fs::path path = builder.opts->sourceDir / (candidate + ".xpm");
        std::error_code ec;
        if (!fs::is_regular_file(path, ec)) {
            continue;
        }
        XpmLoadResult loaded = loadXpm(path.string(), builder.symbols);
        if (!loaded.ok) {
            continue;
        }
        if (chosen != nullptr) {
            *chosen = candidate;
        }
        return loaded.image;
    }
    return Image();
}

struct Slices {
    Image top;
    Image topleft;
    Image topright;
    Image left;
    Image right;
    Image bottom;
    Image bottomleft;
    Image bottomright;
    int topStrip = 0;
    bool usedInactive = false;
};

Slices buildSlices(Builder &builder, const std::string &state, const std::string &prefix)
{
    Slices slices;
    std::string stripName;
    std::string titleName;
    std::string name;

    auto track = [&slices](const std::string &used) {
        if (used.find("inactive") != std::string::npos) {
            slices.usedInactive = true;
        }
    };
    auto record = [&builder, &prefix](const std::string &element, const std::string &used) {
        if (!used.empty()) {
            builder.mapped[prefix + "-" + element] = used + ".xpm";
        }
    };

    const Image strip = pick(builder, {"top-" + state}, &stripName);
    track(stripName);
    const Image title = pick(builder,
        {"title-2-" + state, "title-1-" + state, "title-3-" + state, "title-4-" + state},
        &titleName);
    track(titleName);

    // A short "top" strip is xfwm4's frame border above the title bar; it is
    // stacked on top of the title fill so nothing of the frame is lost.
    if (!title.empty() && !strip.empty() && strip.h < title.h) {
        slices.top = vstack(hstretch(strip, title.w), title);
        slices.topStrip = strip.h;
        builder.mapped[prefix + "-top"] = stripName + ".xpm + " + titleName + ".xpm";
    } else if (!title.empty()) {
        slices.top = title;
        builder.mapped[prefix + "-top"] = titleName + ".xpm";
    } else if (!strip.empty()) {
        slices.top = strip;
        builder.mapped[prefix + "-top"] = stripName + ".xpm";
    }

    const Image topleft = pick(builder, {"top-left-" + state}, &name);
    track(name);
    if (!topleft.empty()) {
        slices.topleft = slices.topStrip > 0 ? vstack(hstretch(strip, topleft.w), topleft) : topleft;
        record("topleft", name);
    }

    const Image topright = pick(builder, {"top-right-" + state}, &name);
    track(name);
    if (!topright.empty()) {
        slices.topright = slices.topStrip > 0 ? vstack(hstretch(strip, topright.w), topright) : topright;
        record("topright", name);
    }

    slices.left = pick(builder, {"left-" + state}, &name);
    track(name);
    record("left", name);

    slices.right = pick(builder, {"right-" + state}, &name);
    track(name);
    record("right", name);

    slices.bottom = pick(builder, {"bottom-" + state}, &name);
    track(name);
    record("bottom", name);

    slices.bottomleft = pick(builder, {"bottom-left-" + state}, &name);
    track(name);
    record("bottomleft", name);

    slices.bottomright = pick(builder, {"bottom-right-" + state}, &name);
    track(name);
    record("bottomright", name);

    return slices;
}

// The title bar band is as tall as the tallest piece that lives in it, so a
// corner that is taller than the title strip still fits inside the canvas.
int titleBand(const Slices &slices)
{
    const int band = std::max(std::max(slices.top.h, slices.topleft.h), slices.topright.h);
    return band > 0 ? band : 24;
}

int bottomBand(const Slices &slices)
{
    const int band = std::max(std::max(slices.bottom.h, slices.bottomleft.h), slices.bottomright.h);
    return band > 0 ? band : 2;
}

int blockHeight(const Slices &slices, int bodyHeight)
{
    return titleBand(slices) + bodyHeight + bottomBand(slices);
}

std::string buildDecorationSvg(const Builder &builder, const Slices &active, const Slices &inactive, bool includeInactive,
    const std::string &themeName)
{
    const int mockWidth = 340;
    const int mockBodyHeight = 150;
    const int gap = 28;

    std::ostringstream body;
    body << "  <!-- " << xmlEscape(themeName) << ": nine slice frame, active and inactive -->\n";

    auto emitBlock = [&body](const Slices &slices, const std::string &prefix, int originX, int originY) {
        const int titleHeight = titleBand(slices);
        const int borderHeight = bottomBand(slices);
        const int leftWidth = slices.left.empty() ? 2 : slices.left.w;
        const int rightWidth = slices.right.empty() ? 2 : slices.right.w;

        const int cornerTopLeftW = slices.topleft.empty() ? leftWidth : slices.topleft.w;
        const int cornerTopLeftH = slices.topleft.empty() ? titleHeight : std::min(slices.topleft.h, titleHeight);
        const int cornerTopRightW = slices.topright.empty() ? rightWidth : slices.topright.w;
        const int cornerTopRightH = slices.topright.empty() ? titleHeight : std::min(slices.topright.h, titleHeight);
        const int cornerBottomLeftW = slices.bottomleft.empty() ? leftWidth : slices.bottomleft.w;
        const int cornerBottomLeftH =
            slices.bottomleft.empty() ? borderHeight : std::min(slices.bottomleft.h, borderHeight);
        const int cornerBottomRightW = slices.bottomright.empty() ? rightWidth : slices.bottomright.w;
        const int cornerBottomRightH =
            slices.bottomright.empty() ? borderHeight : std::min(slices.bottomright.h, borderHeight);

        const int topY = originY;
        const int bodyY = originY + titleHeight;
        const int bottomY = bodyY + mockBodyHeight;

        auto emitImage = [&body](const std::string &id, const Image &image, int x, int y, int width, int height) {
            if (image.empty() || width <= 0 || height <= 0) {
                return;
            }
            body << "  <image id=\"" << id << "\" x=\"" << x << "\" y=\"" << y << "\" width=\"" << width
                 << "\" height=\"" << height << "\" preserveAspectRatio=\"none\" xlink:href=\""
                 << pngDataUri(image) << "\"/>\n";
        };

        emitImage(prefix + "-topleft", slices.topleft, originX, topY, cornerTopLeftW, cornerTopLeftH);
        emitImage(prefix + "-top", slices.top, originX + cornerTopLeftW, topY,
            std::max(1, mockWidth - cornerTopLeftW - cornerTopRightW), titleHeight);
        emitImage(prefix + "-topright", slices.topright, originX + mockWidth - cornerTopRightW, topY, cornerTopRightW,
            cornerTopRightH);
        emitImage(prefix + "-left", slices.left, originX, bodyY, leftWidth, mockBodyHeight);
        emitImage(prefix + "-right", slices.right, originX + mockWidth - rightWidth, bodyY, rightWidth,
            mockBodyHeight);
        body << "  <rect id=\"" << prefix << "-center\" x=\"" << originX + leftWidth << "\" y=\"" << bodyY
             << "\" width=\"" << std::max(1, mockWidth - leftWidth - rightWidth) << "\" height=\"" << mockBodyHeight
             << "\" fill=\"none\"/>\n";
        emitImage(prefix + "-bottomleft", slices.bottomleft, originX, bottomY, cornerBottomLeftW, cornerBottomLeftH);
        emitImage(prefix + "-bottom", slices.bottom, originX + cornerBottomLeftW, bottomY,
            std::max(1, mockWidth - cornerBottomLeftW - cornerBottomRightW), borderHeight);
        emitImage(prefix + "-bottomright", slices.bottomright, originX + mockWidth - cornerBottomRightW, bottomY,
            cornerBottomRightW, cornerBottomRightH);
    };

    const int activeHeight = blockHeight(active, mockBodyHeight);
    const int inactiveHeight = blockHeight(inactive, mockBodyHeight);
    const int totalHeight = includeInactive ? activeHeight + gap + inactiveHeight : activeHeight;

    emitBlock(active, "decoration", 0, 0);
    if (includeInactive) {
        body << "  <!-- inactive windows -->\n";
        emitBlock(inactive, "decoration-inactive", 0, activeHeight + gap);
    }

    std::ostringstream svg;
    svg << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    svg << "<!-- Aurorae decoration generated by xfwm2aurorae from the xfwm4 theme \"" << xmlEscape(themeName)
        << "\" -->\n";
    svg << "<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\"\n";
    svg << "     width=\"" << mockWidth << "\" height=\"" << totalHeight << "\" viewBox=\"0 0 " << mockWidth << " "
        << totalHeight << "\" version=\"1.1\">\n";
    svg << body.str();
    svg << "</svg>\n";
    (void)builder;
    return svg.str();
}

struct ButtonOutcome {
    int width = 0;
    int height = 0;
    std::set<std::string> names;
};

std::string buildButtonSvg(const std::vector<std::pair<std::string, Image>> &states, int width, int height)
{
    std::ostringstream svg;
    svg << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    svg << "<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\"\n";
    svg << "     width=\"" << width * static_cast<int>(states.size()) << "\" height=\"" << height
        << "\" viewBox=\"0 0 " << width * static_cast<int>(states.size()) << " " << height << "\" version=\"1.1\">\n";

    int index = 0;
    for (const auto &state : states) {
        if (state.second.empty()) {
            ++index;
            continue;
        }
        svg << "  <image id=\"" << state.first << "\" x=\"" << index * width << "\" y=\"0\" width=\"" << width
            << "\" height=\"" << height << "\" preserveAspectRatio=\"none\" xlink:href=\""
            << pngDataUri(state.second) << "\"/>\n";
        ++index;
    }

    svg << "</svg>\n";
    return svg.str();
}

ButtonOutcome writeButtons(Builder &builder, const fs::path &outDir)
{
    struct Spec {
        const char *xfwm;
        const char *aurorae;
    };
    static const Spec specs[] = {
        {"close", "close"},
        {"hide", "minimize"},
        {"maximize", "maximize"},
        {"shade", "shade"},
        {"stick", "alldesktops"},
    };

    ButtonOutcome outcome;
    for (const Spec &spec : specs) {
        std::string name;
        const std::string base = spec.xfwm;

        const Image active = pick(builder, {base + "-active", base + "-inactive"}, &name);
        if (active.empty()) {
            continue;
        }
        builder.mapped[std::string(spec.aurorae) + ".svg (active)"] = name + ".xpm";

        Image inactive = pick(builder, {base + "-inactive"}, &name);
        if (inactive.empty()) {
            inactive = active;
        }
        Image hover = pick(builder, {base + "-prelight", base + "-active"}, &name);
        if (hover.empty()) {
            hover = active;
        }
        Image pressed = pick(builder, {base + "-pressed", base + "-toggled-pressed", base + "-active"}, &name);
        if (pressed.empty()) {
            pressed = active;
        }

        // Aurorae names each state as "<state>-center", see its FrameSvg usage.
        const std::vector<std::pair<std::string, Image>> states = {
            {"active-center", active},
            {"inactive-center", inactive},
            {"hover-center", hover},
            {"hover-inactive-center", hover},
            {"pressed-center", pressed},
            {"pressed-inactive-center", pressed},
            {"deactivated-center", inactive},
            {"deactivated-inactive-center", inactive},
        };

        const std::string svg = buildButtonSvg(states, active.w, active.h);
        {
            std::ofstream out(outDir / (std::string(spec.aurorae) + ".svg"), std::ios::binary);
            if (out) {
                out << svg;
            }
        }
        if (std::string(spec.aurorae) == "maximize") {
            // KWin asks for a separate restore pixmap while a window is maximized.
            std::ofstream out(outDir / "restore.svg", std::ios::binary);
            if (out) {
                out << svg;
            }
        }

        builder.mapped[std::string(spec.aurorae) + ".svg (hover)"] = std::string(base) + "-prelight.xpm";
        builder.mapped[std::string(spec.aurorae) + ".svg (pressed)"] = std::string(base) + "-pressed.xpm";

        outcome.names.insert(spec.aurorae);
        if (outcome.width == 0 && outcome.height == 0) {
            outcome.width = active.w;
            outcome.height = active.h;
        }
    }
    return outcome;
}

std::string colorText(const Rgba &color)
{
    std::ostringstream out;
    out << static_cast<int>(color.r) << "," << static_cast<int>(color.g) << "," << static_cast<int>(color.b);
    if (color.a != 255) {
        out << "," << static_cast<int>(color.a);
    }
    return out.str();
}

Rgba readColor(const Themerc &themerc, const SymbolTable &symbols, const std::string &key, const Rgba &fallback)
{
    Rgba color;
    if (resolveColor(themerc.get(key), symbols, color)) {
        return color;
    }
    return fallback;
}

void readShadow(const std::string &value, bool &enabled, int &offsetX, int &offsetY)
{
    const std::string mode = toLower(trim(value));
    enabled = false;
    offsetX = 0;
    offsetY = 0;
    if (mode == "under") {
        enabled = true;
        offsetY = 1;
    } else if (mode == "outset") {
        enabled = true;
        offsetX = 1;
        offsetY = 1;
    } else if (mode == "true" || mode == "1" || mode == "yes") {
        enabled = true;
        offsetY = 1;
    }
}

std::string kwinButtonName(char letter)
{
    switch (letter) {
    case 'M':
        return "menu";
    case 'I':
        return "minimize";
    case 'A':
        return "maximize";
    case 'X':
        return "close";
    case 'L':
        return "shade";
    case 'S':
        return "alldesktops";
    case 'N':
        return "appmenu";
    case 'F':
        return "keepabove";
    case 'B':
        return "keepbelow";
    case 'H':
        return "help";
    default:
        return std::string();
    }
}

// xfwm4 layout letters -> KWin layout letters, split at the title marker.
void mapButtonLayout(const std::string &layout, const std::set<std::string> &available, std::string &leftOut,
    std::string &rightOut)
{
    std::string left;
    std::string right;
    bool afterTitle = false;

    for (char letter : layout) {
        if (letter == '|') {
            afterTitle = true;
            continue;
        }
        if (std::isspace(static_cast<unsigned char>(letter))) {
            continue;
        }
        if (letter == '_') {
            (afterTitle ? right : left).push_back('_');
            continue;
        }

        char converted = '\0';
        switch (letter) {
        case 'O':
            converted = 'M'; // option menu
            break;
        case 'T':
            converted = 'S'; // sticky window -> show on all desktops
            break;
        case 'H':
            converted = 'I'; // hide -> minimize
            break;
        case 'S':
            converted = 'L'; // shade
            break;
        case 'M':
            converted = 'A'; // maximize
            break;
        case 'C':
            converted = 'X'; // close
            break;
        default:
            break;
        }
        if (converted == '\0') {
            continue;
        }

        const std::string name = kwinButtonName(converted);
        if (name.empty()) {
            continue;
        }
        // Menu buttons are drawn from icons by KWin; the rest need our SVG.
        if (name != "menu" && available.count(name) == 0) {
            continue;
        }
        (afterTitle ? right : left).push_back(converted);
    }

    leftOut = left;
    rightOut = right;
}

std::string buildRcFile(const ConvertOptions &options, const Themerc &themerc, const SymbolTable &symbols,
    const Slices &active, const ButtonOutcome &buttons)
{
    const int titleTotal = active.top.empty() ? 24 : active.top.h;
    const int titleEdgeTop = active.topStrip;
    const int titleHeight = std::max(1, titleTotal - titleEdgeTop);
    const int borderLeft = active.left.empty() ? 0 : active.left.w;
    const int borderRight = active.right.empty() ? 0 : active.right.w;
    const int borderBottom = active.bottom.empty() ? 0 : active.bottom.h;
    const int buttonSpacing = std::max(0, themerc.getInt("button_spacing", 2));
    const int buttonOffset = std::max(0, themerc.getInt("button_offset", 0));
    const int titleOffset = themerc.getInt("title_horizontal_offset", 0);

    int buttonHeight = buttons.height > 0 ? buttons.height : titleHeight;
    int buttonWidth = buttons.width > 0 ? buttons.width : buttonHeight;
    if (buttonHeight > titleHeight) {
        const double scale = static_cast<double>(titleHeight) / static_cast<double>(buttonHeight);
        buttonHeight = titleHeight;
        buttonWidth = std::max(1, static_cast<int>(std::lround(static_cast<double>(buttonWidth) * scale)));
    }

    std::string alignment = "Center";
    const std::string rawAlignment = toLower(trim(themerc.get("title_alignment", "center")));
    if (rawAlignment == "left") {
        alignment = "Left";
    } else if (rawAlignment == "right") {
        alignment = "Right";
    }

    bool shadowActive = false;
    bool shadowInactive = false;
    int offsetX = 0;
    int offsetY = 0;
    int unusedX = 0;
    int unusedY = 0;
    readShadow(themerc.get("title_shadow_active", "false"), shadowActive, offsetX, offsetY);
    readShadow(themerc.get("title_shadow_inactive", "false"), shadowInactive, unusedX, unusedY);
    const bool useShadow = shadowActive || shadowInactive;

    const Rgba activeText = readColor(themerc, symbols, "active_text_color", Rgba{255, 255, 255, 255});
    const Rgba inactiveText = readColor(themerc, symbols, "inactive_text_color", Rgba{160, 160, 160, 255});
    const Rgba activeShadow = readColor(themerc, symbols, "active_text_shadow_color", Rgba{0, 0, 0, 160});
    const Rgba inactiveShadow = readColor(themerc, symbols, "inactive_text_shadow_color", Rgba{255, 255, 255, 160});

    std::string leftButtons;
    std::string rightButtons;
    mapButtonLayout(themerc.get("button_layout", "O|HMC"), buttons.names, leftButtons, rightButtons);

    std::ostringstream rc;
    rc << "# Aurorae theme generated by xfwm2aurorae from the xfwm4 theme \"" << options.themeName << "\"\n";
    rc << "# Colours and metrics were carried over from " << (options.sourceDir / "themerc").string() << "\n\n";
    rc << "[General]\n";
    rc << "TitleAlignment=" << alignment << "\n";
    rc << "TitleVerticalAlignment=Center\n";
    rc << "Animation=0\n";
    rc << "ActiveTextColor=" << colorText(activeText) << "\n";
    rc << "InactiveTextColor=" << colorText(inactiveText) << "\n";
    rc << "UseTextShadow=" << (useShadow ? "true" : "false") << "\n";
    rc << "ActiveTextShadowColor=" << colorText(activeShadow) << "\n";
    rc << "InactiveTextShadowColor=" << colorText(inactiveShadow) << "\n";
    rc << "TextShadowOffsetX=" << offsetX << "\n";
    rc << "TextShadowOffsetY=" << offsetY << "\n";
    rc << "HaloActive=false\n";
    rc << "HaloInactive=false\n";
    rc << "LeftButtons=" << leftButtons << "\n";
    rc << "RightButtons=" << rightButtons << "\n";
    rc << "Shadow=false\n";
    rc << "DecorationPosition=0\n\n";

    rc << "[Layout]\n";
    rc << "BorderLeft=" << borderLeft << "\n";
    rc << "BorderRight=" << borderRight << "\n";
    rc << "BorderBottom=" << borderBottom << "\n";
    rc << "BorderTop=0\n";
    rc << "TitleEdgeTop=" << titleEdgeTop << "\n";
    rc << "TitleEdgeBottom=0\n";
    rc << "TitleEdgeLeft=" << buttonOffset << "\n";
    rc << "TitleEdgeRight=" << buttonOffset << "\n";
    rc << "TitleEdgeTopMaximized=0\n";
    rc << "TitleEdgeBottomMaximized=0\n";
    rc << "TitleEdgeLeftMaximized=0\n";
    rc << "TitleEdgeRightMaximized=0\n";
    rc << "TitleBorderLeft=" << std::max(0, titleOffset + 2) << "\n";
    rc << "TitleBorderRight=" << std::max(0, titleOffset + 2) << "\n";
    rc << "TitleHeight=" << titleHeight << "\n";
    rc << "ButtonWidth=" << buttonWidth << "\n";
    rc << "ButtonHeight=" << buttonHeight << "\n";
    rc << "ButtonSpacing=" << buttonSpacing << "\n";
    rc << "ButtonMarginTop=" << std::max(0, (titleHeight - buttonHeight) / 2) << "\n";
    rc << "ExplicitButtonSpacer=10\n";
    rc << "PaddingTop=0\n";
    rc << "PaddingBottom=0\n";
    rc << "PaddingLeft=0\n";
    rc << "PaddingRight=0\n";
    return rc.str();
}

std::string buildMetadata(const std::string &themeName)
{
    std::ostringstream meta;
    meta << "[Desktop Entry]\n";
    meta << "Name=" << themeName << "\n";
    meta << "Comment=Aurorae port of the xfwm4 theme " << themeName << "\n";
    meta << "Type=Service\n";
    meta << "X-KDE-ServiceTypes=KDecoration\n";
    meta << "X-KDE-PluginInfo-Name=" << themeName << "\n";
    meta << "X-KDE-PluginInfo-Author=\n";
    meta << "X-KDE-PluginInfo-Email=\n";
    meta << "X-KDE-PluginInfo-Version=1.0\n";
    meta << "X-KDE-PluginInfo-Website=\n";
    meta << "X-KDE-PluginInfo-License=\n";
    meta << "X-KDE-PluginInfo-EnabledByDefault=true\n";
    return meta.str();
}

} // namespace

ConvertResult convertTheme(const ConvertOptions &options)
{
    ConvertResult result;
    Builder builder;
    builder.opts = &options;
    builder.symbols = SymbolTable::withBuiltins();

    for (const std::string &entry : options.symbolOverrides) {
        const std::size_t equals = entry.find('=');
        if (equals == std::string::npos) {
            result.error = "expected name=#rrggbb, got: " + entry;
            return result;
        }
        Rgba color;
        if (!parseHexColor(entry.substr(equals + 1), color)) {
            result.error = "not a hex colour: " + entry;
            return result;
        }
        builder.symbols.set(entry.substr(0, equals), color);
    }

    std::error_code ec;
    if (!fs::is_directory(options.sourceDir, ec)) {
        result.error = "not a directory: " + options.sourceDir.string();
        return result;
    }

    Themerc themerc;
    std::string themercError;
    if (!loadThemerc((options.sourceDir / "themerc").string(), themerc, themercError)) {
        builder.warnings.push_back(themercError + "; continuing with defaults");
    }

    Slices active = buildSlices(builder, "active", "decoration");
    Slices inactive = buildSlices(builder, "inactive", "decoration-inactive");

    if (active.top.empty() && active.left.empty() && active.bottom.empty() && active.topleft.empty()) {
        active = inactive;
    }
    if (active.top.empty() && active.left.empty() && active.bottom.empty() && active.topleft.empty()) {
        result.error = "no usable .xpm pixmaps found in " + options.sourceDir.string();
        result.warnings = builder.warnings;
        return result;
    }

    fs::create_directories(options.outputDir, ec);
    if (ec) {
        result.error = "cannot create " + options.outputDir.string() + ": " + ec.message();
        result.warnings = builder.warnings;
        return result;
    }

    const bool includeInactive = inactive.usedInactive;

    {
        const std::string svg = buildDecorationSvg(builder, active, inactive, includeInactive, options.themeName);
        std::ofstream out(options.outputDir / "decoration.svg", std::ios::binary);
        if (!out) {
            result.error = "cannot write decoration.svg";
            return result;
        }
        out << svg;
        result.written.push_back("decoration.svg");
    }

    const ButtonOutcome buttons = writeButtons(builder, options.outputDir);
    if (!buttons.names.empty()) {
        for (const std::string &name : buttons.names) {
            result.written.push_back(name + ".svg");
        }
        if (buttons.names.count("maximize") != 0) {
            result.written.push_back("restore.svg");
        }
    }

    {
        const std::string rc = buildRcFile(options, themerc, builder.symbols, active, buttons);
        const std::string fileName = options.themeName + "rc";
        std::ofstream out(options.outputDir / fileName, std::ios::binary);
        if (!out) {
            result.error = "cannot write " + fileName;
            return result;
        }
        out << rc;
        result.written.push_back(fileName);
    }

    {
        std::ofstream out(options.outputDir / "metadata.desktop", std::ios::binary);
        if (!out) {
            result.error = "cannot write metadata.desktop";
            return result;
        }
        out << buildMetadata(options.themeName);
        result.written.push_back("metadata.desktop");
    }

    if (buttons.names.empty()) {
        builder.warnings.push_back("no xfwm4 button pixmaps found; the decoration will have no buttons of its own");
    }

    for (const std::string &symbol : builder.symbols.builtinHits) {
        builder.warnings.push_back("colour symbol '" + symbol
            + "' is not defined by the theme; a built in default was used (override with --symbol " + symbol
            + "=#rrggbb)");
    }

    result.ok = true;
    result.mapped = builder.mapped;
    result.warnings = builder.warnings;
    return result;
}
