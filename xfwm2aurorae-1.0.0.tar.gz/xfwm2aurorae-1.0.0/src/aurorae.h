// Converts an xfwm4 theme folder into an Aurorae theme folder.
#pragma once

#include <filesystem>
#include <map>
#include <string>
#include <vector>

struct ConvertOptions {
    std::filesystem::path sourceDir; // the folder holding themerc and the *.xpm files
    std::filesystem::path outputDir; // Aurorae theme folder to create
    std::string themeName;           // must match the folder and rc file name
    std::vector<std::string> symbolOverrides; // name=#rrggbb entries
};

struct ConvertResult {
    bool ok = false;
    std::string error;
    std::vector<std::string> warnings;
    std::vector<std::string> written;
    std::map<std::string, std::string> mapped; // aurorae element -> source pixmap
};

ConvertResult convertTheme(const ConvertOptions &options);
