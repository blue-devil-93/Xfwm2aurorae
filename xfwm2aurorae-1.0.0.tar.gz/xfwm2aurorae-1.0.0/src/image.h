// Minimal RGBA image used as the interchange format between the XPM loader
// and the SVG writer.
#pragma once

#include <algorithm>
#include <cstdint>
#include <vector>

struct Rgba {
    std::uint8_t r = 0;
    std::uint8_t g = 0;
    std::uint8_t b = 0;
    std::uint8_t a = 0;
};

struct Image {
    int w = 0;
    int h = 0;
    std::vector<Rgba> px;

    bool empty() const { return w <= 0 || h <= 0 || px.empty(); }

    void resize(int width, int height)
    {
        w = width;
        h = height;
        px.assign(static_cast<std::size_t>(width) * static_cast<std::size_t>(height), Rgba{});
    }

    Rgba &at(int x, int y) { return px[static_cast<std::size_t>(y) * static_cast<std::size_t>(w) + x]; }
    const Rgba &at(int x, int y) const { return px[static_cast<std::size_t>(y) * static_cast<std::size_t>(w) + x]; }
};

// Stacks two images vertically, left aligned. Either one may be empty.
inline Image vstack(const Image &top, const Image &bottom)
{
    if (top.empty()) {
        return bottom;
    }
    if (bottom.empty()) {
        return top;
    }

    Image out;
    out.resize(std::max(top.w, bottom.w), top.h + bottom.h);
    for (int y = 0; y < top.h; ++y) {
        for (int x = 0; x < top.w; ++x) {
            out.at(x, y) = top.at(x, y);
        }
    }
    for (int y = 0; y < bottom.h; ++y) {
        for (int x = 0; x < bottom.w; ++x) {
            out.at(x, top.h + y) = bottom.at(x, y);
        }
    }
    return out;
}

// Widens an image by repeating its columns, which is how xfwm4 tiles the
// one pixel wide border strips along an edge.
inline Image hstretch(const Image &src, int width)
{
    if (src.empty() || width <= 0) {
        return src;
    }

    Image out;
    out.resize(width, src.h);
    for (int y = 0; y < src.h; ++y) {
        for (int x = 0; x < width; ++x) {
            out.at(x, y) = src.at(x % src.w, y);
        }
    }
    return out;
}
