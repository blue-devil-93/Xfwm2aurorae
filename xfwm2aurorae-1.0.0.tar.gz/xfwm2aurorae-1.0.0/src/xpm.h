// Small, dependency free XPM (X PixMap) reader.
#pragma once

#include <string>
#include <vector>

#include "image.h"
#include "theme.h"

struct XpmLoadResult {
    bool ok = false;
    Image image;
    std::vector<std::string> warnings;
};

XpmLoadResult loadXpm(const std::string &path, const SymbolTable &symbols);
