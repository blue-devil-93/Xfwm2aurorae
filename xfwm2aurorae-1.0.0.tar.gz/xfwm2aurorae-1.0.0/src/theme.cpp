#include "theme.h"

#include <cctype>
#include <fstream>
#include <sstream>

namespace {

std::string toLower(std::string text)
{
    for (char &c : text) {
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    }
    return text;
}

std::string trim(const std::string &text)
{
    std::size_t begin = 0;
    std::size_t end = text.size();
    while (begin < end && std::isspace(static_cast<unsigned char>(text[begin]))) {
        ++begin;
    }
    while (end > begin && std::isspace(static_cast<unsigned char>(text[end - 1]))) {
        --end;
    }
    return text.substr(begin, end - begin);
}

int hexDigit(char c)
{
    if (c >= '0' && c <= '9') {
        return c - '0';
    }
    if (c >= 'a' && c <= 'f') {
        return c - 'a' + 10;
    }
    if (c >= 'A' && c <= 'F') {
        return c - 'A' + 10;
    }
    return -1;
}

// X11 allows 1, 2, 3 or 4 hex digits per channel.
std::uint8_t channel(const std::string &digits, std::size_t offset, std::size_t count)
{
    unsigned value = 0;
    for (std::size_t i = 0; i < count; ++i) {
        value = value * 16u + static_cast<unsigned>(hexDigit(digits[offset + i]));
    }
    unsigned maximum = (1u << (4u * static_cast<unsigned>(count))) - 1u;
    return static_cast<std::uint8_t>((value * 255u + maximum / 2u) / maximum);
}

} // namespace

SymbolTable SymbolTable::withBuiltins()
{
    SymbolTable table;
    const struct {
        const char *name;
        std::uint8_t r, g, b;
    } defaults[] = {
        {"active_bg", 46, 52, 64},
        {"active_bg_2", 59, 66, 82},
        {"active_fg", 216, 222, 233},
        {"active_text_color", 255, 255, 255},
        {"active_text_color_2", 255, 255, 255},
        {"active_hilight_1", 94, 129, 172},
        {"active_hilight_2", 76, 86, 106},
        {"active_mid_1", 67, 76, 94},
        {"active_mid_2", 67, 76, 94},
        {"active_shadow_1", 46, 52, 64},
        {"active_shadow_2", 46, 52, 64},
        {"active_border", 46, 52, 64},
        {"inactive_bg", 229, 233, 240},
        {"inactive_bg_2", 236, 239, 244},
        {"inactive_fg", 76, 86, 106},
        {"inactive_text_color", 76, 86, 106},
        {"inactive_text_color_2", 76, 86, 106},
        {"inactive_hilight_1", 216, 222, 233},
        {"inactive_hilight_2", 216, 222, 233},
        {"inactive_mid_1", 229, 233, 240},
        {"inactive_mid_2", 229, 233, 240},
        {"inactive_shadow_1", 216, 222, 233},
        {"inactive_shadow_2", 216, 222, 233},
        {"inactive_border", 216, 222, 233},
        {"bg_color", 229, 233, 240},
        {"fg_color", 46, 52, 64},
        {"dark_shadow", 46, 52, 64},
        {"light_shadow", 255, 255, 255},
        {"mid_shadow", 76, 86, 106},
        {"black", 0, 0, 0},
        {"white", 255, 255, 255},
        {"red", 204, 0, 0},
        {"green", 78, 154, 6},
        {"blue", 50, 105, 219},
    };

    for (const auto &entry : defaults) {
        table.colors[toLower(entry.name)] = Rgba{entry.r, entry.g, entry.b, 255};
        table.builtins.insert(toLower(entry.name));
    }
    return table;
}

void SymbolTable::set(const std::string &name, const Rgba &color)
{
    const std::string key = toLower(trim(name));
    colors[key] = color;
    builtins.erase(key);
}

const Rgba *SymbolTable::find(const std::string &name) const
{
    const std::string key = toLower(trim(name));
    auto it = colors.find(key);
    if (it == colors.end()) {
        return nullptr;
    }
    if (builtins.count(key) != 0) {
        builtinHits.insert(key);
    }
    return &it->second;
}

bool parseHexColor(const std::string &text, Rgba &out)
{
    std::string value = trim(text);
    if (value.empty()) {
        return false;
    }
    if (value[0] != '#') {
        value.insert(value.begin(), '#');
    }

    const std::string digits = value.substr(1);
    for (char c : digits) {
        if (hexDigit(c) < 0) {
            return false;
        }
    }

    switch (digits.size()) {
    case 3:
        out = Rgba{channel(digits, 0, 1), channel(digits, 1, 1), channel(digits, 2, 1), 255};
        return true;
    case 4:
        out = Rgba{channel(digits, 0, 1), channel(digits, 1, 1), channel(digits, 2, 1), channel(digits, 3, 1)};
        return true;
    case 6:
        out = Rgba{channel(digits, 0, 2), channel(digits, 2, 2), channel(digits, 4, 2), 255};
        return true;
    case 8:
        out = Rgba{channel(digits, 0, 2), channel(digits, 2, 2), channel(digits, 4, 2), channel(digits, 6, 2)};
        return true;
    case 9:
        out = Rgba{channel(digits, 0, 3), channel(digits, 3, 3), channel(digits, 6, 3), 255};
        return true;
    case 12:
        out = Rgba{channel(digits, 0, 4), channel(digits, 4, 4), channel(digits, 8, 4), 255};
        return true;
    default:
        return false;
    }
}

bool resolveColor(const std::string &text, const SymbolTable &symbols, Rgba &out)
{
    std::string value = trim(text);
    if (value.empty()) {
        return false;
    }

    // xfwm4 accepts a colour list for gradients; the first entry is a good
    // enough approximation for a single flat fill.
    const std::size_t comma = value.find(',');
    if (comma != std::string::npos) {
        value = trim(value.substr(0, comma));
    }

    const std::string lowered = toLower(value);
    if (lowered == "none" || lowered == "transparent") {
        out = Rgba{0, 0, 0, 0};
        return true;
    }
    if (value[0] == '#') {
        return parseHexColor(value, out);
    }
    if (lowered.rfind("rgb:", 0) == 0) {
        value = "#" + value.substr(4);
        return parseHexColor(value, out);
    }
    if (const Rgba *color = symbols.find(value)) {
        out = *color;
        return true;
    }
    return false;
}

bool Themerc::has(const std::string &key) const
{
    return kv.find(toLower(key)) != kv.end();
}

std::string Themerc::get(const std::string &key, const std::string &fallback) const
{
    auto it = kv.find(toLower(key));
    return it == kv.end() ? fallback : it->second;
}

int Themerc::getInt(const std::string &key, int fallback) const
{
    auto it = kv.find(toLower(key));
    if (it == kv.end()) {
        return fallback;
    }
    try {
        return std::stoi(it->second);
    } catch (...) {
        return fallback;
    }
}

bool Themerc::getBool(const std::string &key, bool fallback) const
{
    auto it = kv.find(toLower(key));
    if (it == kv.end()) {
        return fallback;
    }
    const std::string value = toLower(trim(it->second));
    if (value == "1" || value == "true" || value == "yes" || value == "on") {
        return true;
    }
    if (value == "0" || value == "false" || value == "no" || value == "off") {
        return false;
    }
    return fallback;
}

bool loadThemerc(const std::string &path, Themerc &out, std::string &error)
{
    std::ifstream in(path);
    if (!in) {
        error = "cannot open " + path;
        return false;
    }

    std::string line;
    while (std::getline(in, line)) {
        const std::string cleaned = trim(line);
        if (cleaned.empty() || cleaned[0] == '#') {
            continue;
        }
        const std::size_t equals = cleaned.find('=');
        if (equals == std::string::npos) {
            continue;
        }
        const std::string key = toLower(trim(cleaned.substr(0, equals)));
        std::string value = trim(cleaned.substr(equals + 1));
        // Strip a trailing comment, but keep '#' colours intact.
        const std::size_t comment = value.find(" #");
        if (comment != std::string::npos) {
            value = trim(value.substr(0, comment));
        }
        out.kv[key] = value;
    }
    return true;
}
