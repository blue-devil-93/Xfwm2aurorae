// xfwm4 colour symbols and themerc parsing.
#pragma once

#include <map>
#include <set>
#include <string>

#include "image.h"

// xfwm4 pixmaps may refer to colours by name (for example "active_mid_2")
// instead of a literal hex value, so they follow the user's GTK theme. Those
// symbols cannot be read from the theme folder itself; the table below offers
// a reasonable default palette which can be overridden from the command line.
struct SymbolTable {
    std::map<std::string, Rgba> colors;
    std::set<std::string> builtins;
    mutable std::set<std::string> builtinHits;

    static SymbolTable withBuiltins();
    void set(const std::string &name, const Rgba &color);
    const Rgba *find(const std::string &name) const;
};

bool parseHexColor(const std::string &text, Rgba &out);
bool resolveColor(const std::string &text, const SymbolTable &symbols, Rgba &out);

struct Themerc {
    std::map<std::string, std::string> kv;

    bool has(const std::string &key) const;
    std::string get(const std::string &key, const std::string &fallback = std::string()) const;
    int getInt(const std::string &key, int fallback) const;
    bool getBool(const std::string &key, bool fallback) const;
};

bool loadThemerc(const std::string &path, Themerc &out, std::string &error);
