#include "png.h"

#include <cstdint>
#include <cstring>

namespace {

std::uint32_t crcTable[256];
bool crcReady = false;

void buildCrcTable()
{
    for (std::uint32_t n = 0; n < 256; ++n) {
        std::uint32_t c = n;
        for (int k = 0; k < 8; ++k) {
            c = (c & 1u) != 0 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
        }
        crcTable[n] = c;
    }
    crcReady = true;
}

std::uint32_t crc32(const std::string &data)
{
    if (!crcReady) {
        buildCrcTable();
    }
    std::uint32_t c = 0xFFFFFFFFu;
    for (unsigned char byte : data) {
        c = crcTable[(c ^ byte) & 0xFFu] ^ (c >> 8);
    }
    return c ^ 0xFFFFFFFFu;
}

std::uint32_t adler32(const std::string &data)
{
    std::uint32_t a = 1;
    std::uint32_t b = 0;
    for (unsigned char byte : data) {
        a = (a + byte) % 65521u;
        b = (b + a) % 65521u;
    }
    return (b << 16) | a;
}

void appendU32(std::string &out, std::uint32_t value)
{
    out.push_back(static_cast<char>((value >> 24) & 0xFFu));
    out.push_back(static_cast<char>((value >> 16) & 0xFFu));
    out.push_back(static_cast<char>((value >> 8) & 0xFFu));
    out.push_back(static_cast<char>(value & 0xFFu));
}

std::string chunk(const char type[5], const std::string &payload)
{
    std::string body(type, 4);
    body += payload;

    std::string out;
    appendU32(out, static_cast<std::uint32_t>(payload.size()));
    out += body;
    appendU32(out, crc32(body));
    return out;
}

// A valid zlib stream built from uncompressed deflate blocks: larger than a
// real compressor would produce, but exact and free of dependencies.
std::string zlibStore(const std::string &raw)
{
    std::string out;
    out.push_back(static_cast<char>(0x78));
    out.push_back(static_cast<char>(0x01));

    std::size_t position = 0;
    do {
        const std::size_t remaining = raw.size() - position;
        const std::size_t size = remaining < 65535 ? remaining : 65535;
        const bool last = position + size >= raw.size();

        out.push_back(static_cast<char>(last ? 1 : 0));
        out.push_back(static_cast<char>(size & 0xFFu));
        out.push_back(static_cast<char>((size >> 8) & 0xFFu));
        const std::uint16_t inverted = static_cast<std::uint16_t>(~size);
        out.push_back(static_cast<char>(inverted & 0xFFu));
        out.push_back(static_cast<char>((inverted >> 8) & 0xFFu));
        out.append(raw, position, size);
        position += size;
    } while (position < raw.size());

    appendU32(out, adler32(raw));
    return out;
}

} // namespace

std::string encodePng(const Image &image)
{
    if (image.empty()) {
        return std::string();
    }

    std::string out("\x89PNG\r\n\x1a\n", 8);

    std::string header;
    appendU32(header, static_cast<std::uint32_t>(image.w));
    appendU32(header, static_cast<std::uint32_t>(image.h));
    header.push_back(static_cast<char>(8)); // bit depth
    header.push_back(static_cast<char>(6)); // truecolour with alpha
    header.push_back(static_cast<char>(0)); // deflate
    header.push_back(static_cast<char>(0)); // adaptive filtering
    header.push_back(static_cast<char>(0)); // no interlace
    out += chunk("IHDR", header);

    std::string raw;
    raw.reserve(static_cast<std::size_t>(image.h) * (1 + static_cast<std::size_t>(image.w) * 4));
    for (int y = 0; y < image.h; ++y) {
        raw.push_back(static_cast<char>(0)); // filter: none
        for (int x = 0; x < image.w; ++x) {
            const Rgba &pixel = image.at(x, y);
            raw.push_back(static_cast<char>(pixel.r));
            raw.push_back(static_cast<char>(pixel.g));
            raw.push_back(static_cast<char>(pixel.b));
            raw.push_back(static_cast<char>(pixel.a));
        }
    }

    out += chunk("IDAT", zlibStore(raw));
    out += chunk("IEND", std::string());
    return out;
}

std::string base64Encode(const std::string &data)
{
    static const char alphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    std::string out;
    out.reserve(((data.size() + 2) / 3) * 4);

    std::size_t i = 0;
    for (; i + 2 < data.size(); i += 3) {
        const std::uint32_t value = (static_cast<std::uint8_t>(data[i]) << 16)
            | (static_cast<std::uint8_t>(data[i + 1]) << 8) | static_cast<std::uint8_t>(data[i + 2]);
        out.push_back(alphabet[(value >> 18) & 0x3Fu]);
        out.push_back(alphabet[(value >> 12) & 0x3Fu]);
        out.push_back(alphabet[(value >> 6) & 0x3Fu]);
        out.push_back(alphabet[value & 0x3Fu]);
    }

    const std::size_t remaining = data.size() - i;
    if (remaining == 1) {
        const std::uint32_t value = static_cast<std::uint8_t>(data[i]) << 16;
        out.push_back(alphabet[(value >> 18) & 0x3Fu]);
        out.push_back(alphabet[(value >> 12) & 0x3Fu]);
        out += "==";
    } else if (remaining == 2) {
        const std::uint32_t value = (static_cast<std::uint8_t>(data[i]) << 16)
            | (static_cast<std::uint8_t>(data[i + 1]) << 8);
        out.push_back(alphabet[(value >> 18) & 0x3Fu]);
        out.push_back(alphabet[(value >> 12) & 0x3Fu]);
        out.push_back(alphabet[(value >> 6) & 0x3Fu]);
        out.push_back('=');
    }
    return out;
}

std::string pngDataUri(const Image &image)
{
    const std::string png = encodePng(image);
    if (png.empty()) {
        return std::string();
    }
    return "data:image/png;base64," + base64Encode(png);
}
